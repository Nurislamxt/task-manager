# Task Manager (Final Project)

Web application for managing personal tasks:
- user registration / login (Auth.js via Create)
- create / edit / delete tasks (CRUD)
- set deadlines and task status (TODO / IN_PROGRESS / DONE)
- tasks are private: a user can access only their own tasks

## Tech Stack
- React UI
- Server routes in `apps/web/src/app/api/*`
- PostgreSQL (Neon) via `@neondatabase/serverless`

## Setup (Web)

1) Install dependencies
```bash
cd apps/web
bun install
```

2) Configure environment
Copy `.env.example` to `.env` and fill values:
- `DATABASE_URL`
- `AUTH_SECRET`
- `AUTH_URL`

3) Create database schema
Run the SQL in `docs/schema.sql` against your PostgreSQL database.

4) Run the app
```bash
bun run dev
```

Open the dashboard and sign in. You can now manage tasks.

## API
- `GET /api/tasks?search=&sortBy=&statusFilter=`
- `POST /api/tasks` body: `{ title, description?, dueDate?, status? }`
- `PATCH /api/tasks/{id}` body: `{ title?, description?, dueDate?, status? }`
- `DELETE /api/tasks/{id}`

## Manual Test Checklist
- Sign up / sign in
- Create a task with title only
- Edit task title / description / due date / status
- Delete a task
- Verify tasks are not visible to another user account
