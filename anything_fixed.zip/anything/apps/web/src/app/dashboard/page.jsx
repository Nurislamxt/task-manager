"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Search,
  ChevronRight,
  Clock,
  Plus,
  X,
  Pencil,
  Trash2,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function Dashboard() {
  const { data: user, loading: userLoading } = useUser();
  const queryClient = useQueryClient();

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sortBy, setSortBy] = useState("updated_at");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    dueDate: "",
    status: "TODO",
  });

  // Fetch tasks
  const { data: tasksData, isLoading: tasksLoading } = useQuery({
    queryKey: ["tasks", statusFilter, searchQuery, sortBy],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter) params.append("status", statusFilter);
      if (searchQuery) params.append("search", searchQuery);
      if (sortBy) params.append("sortBy", sortBy);

      const response = await fetch(`/api/tasks?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to fetch tasks");
      return response.json();
    },
    enabled: !!user,
  });

  const tasks = tasksData?.tasks || [];

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create task");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setShowCreateModal(false);
      resetForm();
    },
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, ...taskData }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to update task");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setEditingTask(null);
      resetForm();
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete task");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      dueDate: "",
      status: "TODO",
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingTask) {
      updateTaskMutation.mutate({ id: editingTask.id, ...formData });
    } else {
      createTaskMutation.mutate(formData);
    }
  };

  const handleEdit = (task) => {
    setEditingTask(task);
    setFormData({
      title: task.title,
      description: task.description || "",
      dueDate: task.due_date
        ? new Date(task.due_date).toISOString().split("T")[0]
        : "",
      status: task.status,
    });
    setShowCreateModal(true);
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this task?")) {
      deleteTaskMutation.mutate(id);
    }
  };

  const closeModal = () => {
    setShowCreateModal(false);
    setEditingTask(null);
    resetForm();
  };

  const formatDate = (dateString) => {
    if (!dateString) return "No due date";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "TODO":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "IN_PROGRESS":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "DONE":
        return "bg-green-100 text-green-700 border-green-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case "TODO":
        return "To Do";
      case "IN_PROGRESS":
        return "In Progress";
      case "DONE":
        return "Done";
      default:
        return status;
    }
  };

  // Show loading state
  if (userLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white">
        <div className="text-gray-600 font-instrument">Loading...</div>
      </div>
    );
  }

  // Redirect to signin if not authenticated
  if (!user) {
    if (typeof window !== "undefined") {
      window.location.href = "/account/signin?callbackUrl=/dashboard";
    }
    return null;
  }

  // Group tasks by status
  const todoTasks = tasks.filter((t) => t.status === "TODO");
  const inProgressTasks = tasks.filter((t) => t.status === "IN_PROGRESS");
  const doneTasks = tasks.filter((t) => t.status === "DONE");

  const TaskCard = ({ task }) => (
    <li className="rounded-md border border-gray-200 bg-white px-4 py-3 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-medium text-gray-800 leading-snug font-roboto mb-2">
            {task.title}
          </h3>
          {task.description && (
            <p className="text-xs text-gray-600 mb-2 line-clamp-2 font-instrument">
              {task.description}
            </p>
          )}
          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1 text-xs text-gray-500 font-instrument">
              <Clock className="h-3 w-3" />
              <span>{formatDate(task.due_date)}</span>
            </div>
            <span
              className={`text-xs px-2 py-0.5 rounded-full border ${getStatusColor(task.status)} font-instrument font-medium`}
            >
              {getStatusLabel(task.status)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => handleEdit(task)}
            className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
            aria-label="Edit task"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            onClick={() => handleDelete(task.id)}
            className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
            aria-label="Delete task"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </li>
  );

  const TaskColumn = ({ title, tasks }) => (
    <article className="flex w-full flex-col rounded-md border border-gray-200 bg-white min-h-[400px]">
      <header className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-gray-700 font-instrument">
          {title} <span className="text-gray-400">({tasks.length})</span>
        </h2>
      </header>

      <ul className="flex flex-col gap-3 px-4 py-4 flex-1">
        {tasks.length === 0 ? (
          <li className="text-center text-sm text-gray-400 py-8 font-instrument">
            No tasks
          </li>
        ) : (
          tasks.map((task) => <TaskCard key={task.id} task={task} />)
        )}
      </ul>
    </article>
  );

  return (
    <div className="flex h-screen flex-col bg-white">
      {/* Top Navigation */}
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-200 bg-white px-4 py-2 md:px-8 h-[60px]">
        <div className="flex items-center gap-6">
          <h1 className="text-base font-semibold tracking-wider text-[#111827] font-patrick">
            TASKFLOW
          </h1>
          <nav className="hidden md:flex items-center gap-6">
            <a
              href="/dashboard"
              className="text-sm text-gray-900 underline font-instrument"
            >
              Dashboard
            </a>
            <a
              href="/account/logout"
              className="text-sm text-[#6B7280] hover:text-gray-900 font-instrument"
            >
              Sign Out
            </a>
          </nav>
        </div>

        <div className="flex-1 flex justify-center px-4">
          <div className="relative w-full max-w-[280px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-gray-200 pl-10 pr-4 py-1.5 text-sm text-[#6B7280] font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              resetForm();
              setEditingTask(null);
              setShowCreateModal(true);
            }}
            className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 transition-colors font-instrument"
          >
            <Plus className="inline h-4 w-4 mr-1" />
            New Task
          </button>
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm font-semibold">
              {user.email?.[0]?.toUpperCase() || "U"}
            </div>
            <span className="text-sm text-[#111827] font-instrument hidden sm:inline">
              {user.email}
            </span>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <main className="flex-1 overflow-y-auto px-4 py-6 md:px-8">
          <nav aria-label="Breadcrumb">
            <ol className="flex items-center gap-1 text-xs text-[#9CA3AF] font-instrument">
              <li>Dashboard</li>
              <ChevronRight className="h-3 w-3" />
              <li>Task Manager</li>
            </ol>
          </nav>

          <div className="mt-4 flex items-center justify-between">
            <h1 className="text-3xl font-light text-[#111827] font-roboto">
              My Tasks
            </h1>
            <div className="flex items-center gap-3">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="rounded-md border border-gray-200 px-3 py-1.5 text-sm font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Status</option>
                <option value="TODO">To Do</option>
                <option value="IN_PROGRESS">In Progress</option>
                <option value="DONE">Done</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="rounded-md border border-gray-200 px-3 py-1.5 text-sm font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="updated_at">Recently Updated</option>
                <option value="created_at">Recently Created</option>
                <option value="due_date">Due Date</option>
                <option value="title">Title</option>
              </select>
            </div>
          </div>

          {tasksLoading ? (
            <div className="mt-8 text-center text-gray-600 font-instrument">
              Loading tasks...
            </div>
          ) : (
            <section className="mt-8 flex flex-col gap-6 md:flex-row md:gap-6">
              <TaskColumn title="To Do" tasks={todoTasks} />
              <TaskColumn title="In Progress" tasks={inProgressTasks} />
              <TaskColumn title="Done" tasks={doneTasks} />
            </section>
          )}
        </main>
      </div>

      {/* Create/Edit Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 font-roboto">
                {editingTask ? "Edit Task" : "Create New Task"}
              </h2>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 font-instrument">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  maxLength={255}
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-gray-900 font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter task title"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 font-instrument">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  rows={3}
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-gray-900 font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Add task description..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 font-instrument">
                  Due Date
                </label>
                <input
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) =>
                    setFormData({ ...formData, dueDate: e.target.value })
                  }
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-gray-900 font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 font-instrument">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) =>
                    setFormData({ ...formData, status: e.target.value })
                  }
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-gray-900 font-instrument focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="TODO">To Do</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="DONE">Done</option>
                </select>
              </div>

              {(createTaskMutation.error || updateTaskMutation.error) && (
                <div className="rounded-md bg-red-50 border border-red-200 p-3 text-sm text-red-600 font-instrument">
                  {createTaskMutation.error?.message ||
                    updateTaskMutation.error?.message}
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={
                    createTaskMutation.isPending || updateTaskMutation.isPending
                  }
                  className="flex-1 rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-instrument"
                >
                  {createTaskMutation.isPending || updateTaskMutation.isPending
                    ? "Saving..."
                    : editingTask
                      ? "Update Task"
                      : "Create Task"}
                </button>
                <button
                  type="button"
                  onClick={closeModal}
                  className="flex-1 rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors font-instrument"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Patrick+Hand&family=Instrument+Sans:wght@400;500;600&family=Roboto:wght@300;400;500&display=swap');
        
        .font-patrick {
          font-family: 'Patrick Hand', cursive;
        }
        
        .font-instrument {
          font-family: 'Instrument Sans', sans-serif;
        }
        
        .font-roboto {
          font-family: 'Roboto', sans-serif;
        }
      `}</style>
    </div>
  );
}
