import sql from "../../utils/sql";
import { requireUser } from "../../utils/auth";

const ALLOWED_STATUS = new Set(["TODO", "IN_PROGRESS", "DONE"]);

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function parseId(params) {
  const id = Number(params?.id);
  if (!Number.isInteger(id) || id <= 0) return null;
  return id;
}

export async function PATCH(request, { params }) {
  let user;
  try {
    user = await requireUser(request);
  } catch (e) {
    return e;
  }

  const id = parseId(params);
  if (!id) return json({ error: "Invalid id" }, 400);

  const body = await request.json().catch(() => null);
  if (!body) return json({ error: "Invalid body" }, 400);

  const title = typeof body.title === "string" ? body.title.trim().slice(0, 255) : null;
  const description = typeof body.description === "string" ? body.description.trim() : null;
  const dueDate = body.dueDate ? new Date(body.dueDate) : null;
  const status = ALLOWED_STATUS.has(body.status) ? body.status : null;

  // Ensure the task belongs to the user
  const existing = await sql`
    SELECT id FROM tasks WHERE id = ${id} AND user_id = ${user.id}
  `;
  if (existing.length === 0) return json({ error: "Not found" }, 404);

  const [row] = await sql`
    UPDATE tasks
    SET
      title = COALESCE(${title}, title),
      description = COALESCE(${description}, description),
      due_date = COALESCE(${dueDate}, due_date),
      status = COALESCE(${status}, status),
      updated_at = NOW()
    WHERE id = ${id} AND user_id = ${user.id}
    RETURNING id, title, description, due_date, status, created_at, updated_at
  `;

  return json(row);
}

export async function DELETE(request, { params }) {
  let user;
  try {
    user = await requireUser(request);
  } catch (e) {
    return e;
  }

  const id = parseId(params);
  if (!id) return json({ error: "Invalid id" }, 400);

  const res = await sql`
    DELETE FROM tasks WHERE id = ${id} AND user_id = ${user.id}
    RETURNING id
  `;
  if (res.length === 0) return json({ error: "Not found" }, 404);

  return json({ ok: true });
}
