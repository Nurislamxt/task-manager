import sql from "../utils/sql";
import { requireUser } from "../utils/auth";

const ALLOWED_SORT = new Set(["created_at", "due_date", "status", "title"]);
const ALLOWED_STATUS = new Set(["TODO", "IN_PROGRESS", "DONE"]);

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export async function GET(request) {
  let user;
  try {
    user = await requireUser(request);
  } catch (e) {
    return e;
  }

  const url = new URL(request.url);
  const search = (url.searchParams.get("search") || "").trim();
  const sortBy = (url.searchParams.get("sortBy") || "created_at").trim();
  const statusFilter = (url.searchParams.get("statusFilter") || "").trim();

  const orderCol = ALLOWED_SORT.has(sortBy) ? sortBy : "created_at";
  const status = ALLOWED_STATUS.has(statusFilter) ? statusFilter : null;

  const like = `%${search}%`;

  const rows = await sql`
    SELECT id, title, description, due_date, status, created_at, updated_at
    FROM tasks
    WHERE user_id = ${user.id}
      AND (${search === ""} OR (title ILIKE ${like} OR COALESCE(description,'') ILIKE ${like}))
      AND (${status === null} OR status = ${status})
    ORDER BY ${sql.unsafe(orderCol)} DESC
  `;

  return json({ tasks: rows });
}

export async function POST(request) {
  let user;
  try {
    user = await requireUser(request);
  } catch (e) {
    return e;
  }

  const body = await request.json().catch(() => null);
  if (!body?.title || typeof body.title !== "string" || body.title.trim().length === 0) {
    return json({ error: "Title is required" }, 400);
  }

  const title = body.title.trim().slice(0, 255);
  const description = typeof body.description === "string" ? body.description.trim() : "";
  const dueDate = body.dueDate ? new Date(body.dueDate) : null;

  const status = ALLOWED_STATUS.has(body.status) ? body.status : "TODO";

  const [row] = await sql`
    INSERT INTO tasks (user_id, title, description, due_date, status)
    VALUES (${user.id}, ${title}, ${description}, ${dueDate}, ${status})
    RETURNING id, title, description, due_date, status, created_at, updated_at
  `;

  return json(row, 201);
}
