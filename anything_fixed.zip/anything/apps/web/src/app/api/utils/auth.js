import { getToken } from "@auth/core/jwt";

/**
 * Extract authenticated user from the request using Auth.js JWT.
 * Returns { id, email, name } or throws a Response(401).
 */
export async function requireUser(request) {
  const jwt = await getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: String(process.env.AUTH_URL || "").startsWith("https"),
  });

  if (!jwt?.sub) {
    throw new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  return {
    id: jwt.sub,
    email: jwt.email || null,
    name: jwt.name || null,
  };
}
