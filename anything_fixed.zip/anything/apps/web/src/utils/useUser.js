import * as React from "react";
import { useSession } from "@auth/create/react";

/**
 * Unified user hook used by the dashboard.
 * Returns: { data: user|null, loading: boolean, refetch: fn }
 */
export default function useUser() {
  const { data: session, status } = useSession();

  const user = session?.user
    ? {
        id: session.user.id,
        email: session.user.email || null,
        name: session.user.name || null,
      }
    : null;

  // Auth.js handles refreshing session internally; we keep refetch for compatibility.
  const refetch = React.useCallback(() => {}, []);

  return { data: user, user, loading: status === "loading", refetch };
}
